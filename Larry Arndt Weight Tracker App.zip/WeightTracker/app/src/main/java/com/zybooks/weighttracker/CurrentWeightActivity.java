package com.zybooks.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class CurrentWeightActivity extends AppCompatActivity {

    TextView lWeight, tester;
    EditText tWeight;
    Button submit;
    String message = "You met your goal weight!";

    AccountDatabase accountDatabase;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_weight);


        lWeight = findViewById(R.id.lastWeight);
        tWeight = findViewById(R.id.todaysWeight);
        submit = findViewById(R.id.buttonSubmitWeight);
        tester = findViewById(R.id.test);
        Intent intent = getIntent();
        String uName = intent.getStringExtra("username");

        tester.setText(uName);


        accountDatabase = AccountDatabase.getInstance(getApplicationContext());

        Cursor lastWeight = accountDatabase.getCurrentWeight(uName);
        String lW = lastWeight.getString(1);
        lWeight.setText(lW);


        // test if person left program after they met their goal weight
        //  and did not refill out the Gather info send them back to it

        int lNum =Integer.parseInt(lW);
        Cursor goalWeight = accountDatabase.getGoalWeight(uName);
        String gW = goalWeight.getString(1);
        int gNum =Integer.parseInt(gW);

        if (lNum <= gNum){

            Intent j = new Intent(CurrentWeightActivity.this,GatherDataActivity.class);
            j.putExtra("username",uName);
            startActivity(j);
        }




        tWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String weightInput = tWeight.getText().toString().trim();
                submit.setEnabled(!weightInput.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Boolean exception = false;
                String tInput = tWeight.getText().toString();

                int tNum = 0;
                try {
                    tNum =Integer.parseInt(tInput);
                }
                catch (NumberFormatException ex){

                    exception = true;
                }

                if(exception){
                    Toast.makeText(CurrentWeightActivity.this,"Number too Large",Toast.LENGTH_LONG).show();
                }

                else{


                    Boolean tGood = accountDatabase.addCurrentWeight(tNum, uName);
                    if (tGood){
                        Cursor lastWeight = accountDatabase.getCurrentWeight(uName);
                        String lW = lastWeight.getString(1);
                        int lNum =Integer.parseInt(lW);
                        lWeight.setText(lW);
                        tWeight.setText(null);
                        Cursor goalWeight = accountDatabase.getGoalWeight(uName);
                        String gW = goalWeight.getString(1);


                        int gNum =Integer.parseInt(gW);




                        accountDatabase.getAllCurrentWeight(uName);

                        if (lNum <= gNum) {

                            Cursor userPermision = accountDatabase.getPref(uName);
                            String uP = userPermision.getString(1);
                            String testPref = "YES";



                            //  check if user said yes to permission in the database
                            //  of so this will send the text message if text permission
                            // allow has also been selected

                            if(uP.equals(testPref)){

                                if(checkPermission(Manifest.permission.SEND_SMS)) {

                                    Cursor phoneNumber = accountDatabase.getPhoneNumber(uName);
                                    String pNum = phoneNumber.getString(1);
                                    SmsManager smsManager = SmsManager.getDefault();
                                    smsManager.sendTextMessage(pNum, null, message, null, null);
                                    Toast.makeText(CurrentWeightActivity.this, "Message Sent", Toast.LENGTH_LONG).show();
                                }}

                            Intent intent = new Intent(CurrentWeightActivity.this,GatherDataActivity.class);
                            intent.putExtra("username",uName);
                            startActivity(intent);






                    }
                    else {
                        Toast.makeText(CurrentWeightActivity.this,"Failed To insert Data",Toast.LENGTH_SHORT).show();}
            }}}
        });







    }

    @Override
    public void onBackPressed() {
        // go back to main page
        Intent intent = new Intent(CurrentWeightActivity.this,MainActivity.class);
        startActivity(intent);

    }

    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this,permission);
        return (check == PackageManager.PERMISSION_GRANTED);

    }



}