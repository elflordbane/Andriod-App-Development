package com.zybooks.weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    EditText uName, uPassword;
    Button login, newAccount;
    AccountDatabase accountDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        uName = findViewById(R.id.usernameEditText);
        uPassword = findViewById(R.id.passwordEditText);
        login = findViewById(R.id.buttonLogin);
        newAccount = findViewById(R.id.buttonAddAccount);
        accountDatabase = AccountDatabase.getInstance(getApplicationContext());
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userCheck = uName.getText().toString();
                String passCheck = uPassword.getText().toString();
                Cursor cursor = accountDatabase.getData();
                if(cursor.getCount() == 0){
                    Toast.makeText(MainActivity.this,"No entries Exists",Toast.LENGTH_LONG).show();
                }

                if (loginCheck(cursor,userCheck,passCheck)) {

                    // test if the user created account and left the program before
                    // entering data send them back to data gathering

                    Cursor lastWeight = accountDatabase.getCurrentWeight(userCheck);
                    if(lastWeight.moveToFirst()){


                        Intent intent = new Intent(MainActivity.this,CurrentWeightActivity.class);
                        intent.putExtra("username",userCheck);
                        uName.setText("");
                        uPassword.setText("");
                        startActivity(intent);}

                    else{
                        Intent intent = new Intent(MainActivity.this,Notifications.class);
                        intent.putExtra("username", userCheck);
                        startActivity(intent);

                    }



                }else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle("Wrong Credential");
                    builder.setMessage("Wrong Credential");
                    builder.show();
                }
                accountDatabase.close();

            }
        });

        newAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userCheck = uName.getText().toString();
                String passCheck = uPassword.getText().toString();
                Boolean good = accountDatabase.addUser(userCheck, passCheck);
                if (good){
                    Toast.makeText(MainActivity.this,"Data inserted",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this,Notifications.class);
                    intent.putExtra("username", userCheck);
                    startActivity(intent);
                }else {
                    Toast.makeText(MainActivity.this,"Failed To insert Data",Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

    public static boolean loginCheck(Cursor cursor,String userCheck,String passCheck) {
        while (cursor.moveToNext()){
            if (cursor.getString(0).equals(userCheck)) {
                if (cursor.getString(1).equals(passCheck)) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }

}