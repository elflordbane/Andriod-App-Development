package com.zybooks.weighttracker;


import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class AccountDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "account.db";
    private static final int VERSION = 1;

    private static AccountDatabase accountdb;


    public static AccountDatabase getInstance(Context context) {
        if (accountdb == null) {
            accountdb = new AccountDatabase(context);
        }
        return accountdb;
    }

    public AccountDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class AccountTable {
        private static final String TABLE = "account";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class CurrentWeightTable {
        private static final String TABLE = "currentWeight";
        private static final String COL_ID = "_id";
        private static final String COL_CURRENT = "weight";
        private static final String COL_CUSERNAME = "Cusername";
    }

    private static final class GoalWeightTable {
        private static final String TABLE = "goalWeight";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "weight";
        private static final String COL_GUSERNAME = "Gusername";
    }

    private static final class PhoneNumberTable {
        private static final String TABLE = "phoneNumber";
        private static final String COL_ID = "_id";
        private static final String COL_NUMBER = "number";
        private static final String COL_PUSERNAME = "Pusername";
    }

    private static final class TextPrefTable {
        private static final String TABLE = "testPref";
        private static final String COL_ID = "_id";
        private static final String COL_PREF = "pref";
        private static final String COL_TUSERNAME = "Tusername";
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + AccountTable.TABLE + " (" +
                AccountTable.COL_USERNAME + "  primary key, " +
                AccountTable.COL_PASSWORD + " )");

        db.execSQL("create table " + AccountDatabase.CurrentWeightTable.TABLE + " (" +
                AccountDatabase.CurrentWeightTable.COL_ID + " integer primary key autoincrement, " +
                AccountDatabase.CurrentWeightTable.COL_CURRENT + " int," +
                AccountDatabase.CurrentWeightTable.COL_CUSERNAME + ")");

        db.execSQL("create table " + AccountDatabase.GoalWeightTable.TABLE + " (" +
                AccountDatabase.GoalWeightTable.COL_ID + " integer primary key autoincrement, " +
                AccountDatabase.GoalWeightTable.COL_GOAL + " int," +
                AccountDatabase.GoalWeightTable.COL_GUSERNAME + ")");

        db.execSQL("create table " + AccountDatabase.PhoneNumberTable.TABLE + " (" +
                AccountDatabase.PhoneNumberTable.COL_ID + " integer primary key autoincrement, " +
                AccountDatabase.PhoneNumberTable.COL_NUMBER + " long," +
                AccountDatabase.PhoneNumberTable.COL_PUSERNAME + ")");

        db.execSQL("create table " + AccountDatabase.TextPrefTable.TABLE + " (" +
                AccountDatabase.TextPrefTable.COL_ID + " integer primary key autoincrement, " +
                AccountDatabase.TextPrefTable.COL_PREF + "," +
                AccountDatabase.TextPrefTable.COL_TUSERNAME + ")");



    }

    public Boolean addUser(String uName, String uPassword) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AccountDatabase.AccountTable.COL_USERNAME, uName);
        values.put(AccountDatabase.AccountTable.COL_PASSWORD, uPassword);

        long accountId = db.insert(AccountDatabase.AccountTable.TABLE, null, values);
        if (accountId == -1)
        {return false;}
        else
        {return true;}
    }

    public Boolean addCurrentWeight(int cWeight, String uName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AccountDatabase.CurrentWeightTable.COL_CURRENT, cWeight);
        values.put(AccountDatabase.CurrentWeightTable.COL_CUSERNAME, uName);

        long weightId = db.insert(AccountDatabase.CurrentWeightTable.TABLE, null, values);
        if (weightId == -1)
        {return false;}
        else
        {return true;}
    }

    public Boolean addGoalWeight(int gWeight, String uName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AccountDatabase.GoalWeightTable.COL_GOAL, gWeight);
        values.put(AccountDatabase.GoalWeightTable.COL_GUSERNAME, uName);

        long weightId = db.insert(AccountDatabase.GoalWeightTable.TABLE, null, values);
        if (weightId == -1)
        {return false;}
        else
        {return true;}
    }


    public Boolean addPhoneNumber(long pNumber, String uName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AccountDatabase.PhoneNumberTable.COL_NUMBER, pNumber);
        values.put(AccountDatabase.PhoneNumberTable.COL_PUSERNAME, uName);

        long numberId = db.insert(AccountDatabase.PhoneNumberTable.TABLE, null, values);
        if (numberId == -1)
        {return false;}
        else
        {return true;}
    }

    public Boolean addTextPref(String tPref, String uName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AccountDatabase.TextPrefTable.COL_PREF, tPref);
        values.put(AccountDatabase.TextPrefTable.COL_TUSERNAME, uName);

        long prefId = db.insert(AccountDatabase.TextPrefTable.TABLE, null, values);
        if (prefId == -1)
        {return false;}
        else
        {return true;}
    }




    public Cursor getData(){
        String sql = "select * from " + AccountTable.TABLE;
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,null);
        return cursor;
    }

    public Cursor getCurrentWeight(String uName){
        String sql = "select * from " + AccountDatabase.CurrentWeightTable.TABLE + " where " + CurrentWeightTable.COL_CUSERNAME + " = ?";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,new String[] {uName});
        cursor.moveToLast();
        return cursor;
    }

    public Cursor getGoalWeight(String uName){
        String sql = "select * from " + AccountDatabase.GoalWeightTable.TABLE + " where " + GoalWeightTable.COL_GUSERNAME + " = ?";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,new String[] {uName});
        cursor.moveToLast();
        return cursor;
    }

    public Cursor getPhoneNumber(String uName){
        String sql = "select * from " + AccountDatabase.PhoneNumberTable.TABLE + " where " + PhoneNumberTable.COL_PUSERNAME + " = ?";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,new String[] {uName});
        cursor.moveToLast();
        return cursor;
    }

    public Cursor getPref(String uName){
        String sql = "select * from " + AccountDatabase.TextPrefTable.TABLE + " where " + TextPrefTable.COL_TUSERNAME + " = ?";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,new String[] {uName});
        cursor.moveToLast();
        return cursor;
    }


    public void getAllCurrentWeight(String uName){
        String sql = "select * from " + AccountDatabase.CurrentWeightTable.TABLE + " where " + CurrentWeightTable.COL_CUSERNAME + " = ?";
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery(sql ,new String[] { uName });
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                int weight = cursor.getInt(1);
                String user = cursor.getString(2);
                Log.d(TAG, "User Weight = " + id + ", " + weight + ", " + user );
            } while (cursor.moveToNext());
        }


        cursor.close();
    }





    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + AccountDatabase.AccountTable.TABLE);
        db.execSQL("drop table if exists " + AccountDatabase.CurrentWeightTable.TABLE);
        db.execSQL("drop table if exists " + AccountDatabase.GoalWeightTable.TABLE);
        db.execSQL("drop table if exists " + AccountDatabase.PhoneNumberTable.TABLE);
        db.execSQL("drop table if exists " + AccountDatabase.TextPrefTable.TABLE);
        onCreate(db);

    }
}