package com.zybooks.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class GatherDataActivity extends AppCompatActivity {


    final int SMS_REQUEST_CODE = 1;
    private EditText phonNumber;
    private EditText cWeight;
    private EditText gWeight;
    private Button bSubmit;
    TextView lWeight;
    AccountDatabase accountDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gather_data);



        phonNumber = findViewById(R.id.phone);
        cWeight = findViewById(R.id.current);
        gWeight = findViewById(R.id.goal);
        bSubmit = findViewById(R.id.submit);
        lWeight = findViewById(R.id.lastWeight);
        accountDatabase = AccountDatabase.getInstance(getApplicationContext());
        Intent intent = getIntent();
        String uName = intent.getStringExtra("username");

        lWeight.setText(uName);

        phonNumber.addTextChangedListener(submitTextWatcher);
        cWeight.addTextChangedListener(submitTextWatcher);
        gWeight.addTextChangedListener(submitTextWatcher);

        Cursor userPermision = accountDatabase.getPref(uName);
        String uP = userPermision.getString(1);
        String testPref = "YES";

        if(uP.equals(testPref)){

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_REQUEST_CODE);

        }



        bSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Boolean exception = false;
                String pInput = phonNumber.getText().toString();

                long pNum = 0;
                try {
                    pNum =Long.parseLong(pInput);
                }
                catch (NumberFormatException ex){
                    exception = true;
                }

                String cInput = cWeight.getText().toString();

                int cNum = 0;
                try {
                    cNum = Integer.parseInt(cInput);
                }
                catch (NumberFormatException ex){

                    exception = true;
                }

                String gInput = gWeight.getText().toString();

                int gNum = 0;
                try {
                    gNum = Integer.parseInt(gInput);
                }
                catch (NumberFormatException ex){

                    exception = true;
                }

                if(exception){
                    Toast.makeText(GatherDataActivity.this,"Number too Large",Toast.LENGTH_LONG).show();
                }

                else{

                    Boolean pGood = accountDatabase.addPhoneNumber(pNum, uName);
                    Boolean cGood = accountDatabase.addCurrentWeight(cNum, uName);
                    Boolean gGood = accountDatabase.addGoalWeight(gNum, uName);
                    if (cNum <= gNum)
                        {Toast.makeText(GatherDataActivity.this,"Goal Weight is met, try again.",Toast.LENGTH_LONG).show();}
                    else
                    {if (pGood && cGood && gGood){
                        Toast.makeText(GatherDataActivity.this,"Data inserted",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(GatherDataActivity.this,CurrentWeightActivity.class);
                        intent.putExtra("username",uName);
                        startActivity(intent);
                    }else {
                        Toast.makeText(GatherDataActivity.this,"Failed To insert Data",Toast.LENGTH_SHORT).show();
                }}}
            }
        });




    }

        private TextWatcher submitTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                String phoneInput = phonNumber.getText().toString().trim();
                String currentWeightInput = cWeight.getText().toString().trim();
                String goalWeightInput = gWeight.getText().toString().trim();

                bSubmit.setEnabled(!phoneInput.isEmpty() && !currentWeightInput.isEmpty() && !goalWeightInput.isEmpty());

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        };

    @Override
    public void onBackPressed() {
        // Do nothing

        }

    }
