package com.zybooks.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Notifications extends AppCompatActivity {



    Button yes, no;
    String n = "NO";
    String y = "YES";
    Boolean tGood;
    AccountDatabase accountDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        yes = findViewById(R.id.yesButton);
        no = findViewById(R.id.noButton);

        accountDatabase = AccountDatabase.getInstance(getApplicationContext());
        Intent intent = getIntent();
        String uName = intent.getStringExtra("username");

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tGood = accountDatabase.addTextPref(y,uName);

                if (tGood){
                    Toast.makeText(Notifications.this,"Notification Preference inserted",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Notifications.this,GatherDataActivity.class);
                    intent.putExtra("username",uName);
                    startActivity(intent);
                }else {
                    Toast.makeText(Notifications.this,"Failed To insert Preference",Toast.LENGTH_SHORT).show();
                }


            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tGood = accountDatabase.addTextPref(n,uName);

                if (tGood){
                    Toast.makeText(Notifications.this,"Notification Preference inserted",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Notifications.this,GatherDataActivity.class);
                    intent.putExtra("username",uName);
                    startActivity(intent);
                }else {
                    Toast.makeText(Notifications.this,"Failed To insert Preference",Toast.LENGTH_SHORT).show();
                }


            }
        });





    }

    @Override
    public void onBackPressed() {
        // Do nothing

    }


}